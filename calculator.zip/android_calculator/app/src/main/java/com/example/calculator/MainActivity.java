package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onButtonClick(View view){
        EditText block1 = (EditText)findViewById(R.id.num1);
        EditText block2 = (EditText)findViewById(R.id.num2);
        TextView resultBlock = (TextView)findViewById(R.id.result);
        int num1 = Integer.parseInt(block1.getText().toString());
        int num2 = Integer.parseInt(block2.getText().toString());
        int result = num1 + num2;
        resultBlock.setText(Integer.toString(result));
    }
    public void onButtonClick2(View view){
        EditText block1 = (EditText)findViewById(R.id.num1);
        EditText block2 = (EditText)findViewById(R.id.num2);
        TextView resultBlock = (TextView)findViewById(R.id.result);
        int num1 = Integer.parseInt(block1.getText().toString());
        int num2 = Integer.parseInt(block2.getText().toString());
        int result = num1 * num2;
        resultBlock.setText(Integer.toString(result));
    }
    public void onButtonClick3(View view){
        EditText block1 = (EditText)findViewById(R.id.num1);
        EditText block2 = (EditText)findViewById(R.id.num2);
        TextView resultBlock = (TextView)findViewById(R.id.result);
        int num1 = Integer.parseInt(block1.getText().toString());
        int num2 = Integer.parseInt(block2.getText().toString());
        int result = num1 / num2;
        resultBlock.setText(Integer.toString(result));
    }
    public void onButtonClick4(View view){
        EditText block1 = (EditText)findViewById(R.id.num1);
        EditText block2 = (EditText)findViewById(R.id.num2);
        TextView resultBlock = (TextView)findViewById(R.id.result);
        int num1 = Integer.parseInt(block1.getText().toString());
        int num2 = Integer.parseInt(block2.getText().toString());
        int result = num1 - num2;
        resultBlock.setText(Integer.toString(result));
    }
}